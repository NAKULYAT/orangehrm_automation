package com.selenium.orange_tests;
import java.io.IOException;

import org.testng.annotations.Test;

import com.selenium.orange_pages.BaseTest;
import com.selenium.orange_pages.EmployeeListPage;
import com.selenium.orange_pages.LoginPage;
import com.selenium.orange_pages.PIMPage;
import com.selenium.orange_pages.PersonalDetailsPage;

public class TestWork extends BaseTest {

    @Test(priority = 1)
    public void testLogin() {
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        LoginPage login = new LoginPage(driver);
        try {
			login.login("Admin", "admin123");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @Test(priority = 2)
    public void testNavigateToAddEmployee() {
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewPersonalDetails/empNumber/215");
        PIMPage pim = new PIMPage(driver);
        pim.navigateToAddEmployee();
    }

    @Test(priority = 3)
    public void testAddEmployeeDetails() throws InterruptedException, IOException {
        PIMPage pim = new PIMPage(driver);
        pim.addEmployee("nakulya", "thurai", "sentil", "nakulya", "nakul@123", "nakul@123");
    }

    @Test(priority = 4)
    public void testSearchAndEditEmployee() throws Exception {
        EmployeeListPage empList = new EmployeeListPage(driver);
        empList.searchAndEdit("nakulya");
    }

    @Test(priority = 5)
    public void testEditPersonalDetails() {
        PersonalDetailsPage personal = new PersonalDetailsPage(driver);
        personal.editDetails();//abcd
    }
}
