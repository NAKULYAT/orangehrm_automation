package com.selenium.orange_pages;


import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import java.util.List;

public class PersonalDetailsPage {
    WebDriver driver;

    public PersonalDetailsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void editDetails() {
        List<WebElement> options = driver.findElements(By.xpath("//div[@class='oxd-select-text oxd-select-text--active']"));
        options.get(0).click();
        List<WebElement> nationality = driver.findElements(By.xpath("//div[contains(@class, 'oxd-select-dropdown')]//div"));
        nationality.get(82).click();

        options.get(1).click();
        List<WebElement> marital = driver.findElements(By.xpath("//div[contains(@class, 'oxd-select-dropdown')]//div"));
        marital.get(1).click();

        driver.findElement(By.xpath("(//span[@class='oxd-radio-input oxd-radio-input--active --label-right oxd-radio-input'])[2]")).click();
        driver.findElement(By.xpath("//div[@class='orangehrm-horizontal-padding orangehrm-vertical-padding']//button[@type='submit'][normalize-space()='Save']")).click();
    }
}
