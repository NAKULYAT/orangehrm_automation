package com.selenium.orange_pages;


import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

import com.selenium.orange_utils.ScreenshotUtil;

import java.io.IOException;


public class EmployeeListPage {
    WebDriver driver;

    @FindBy(xpath = "//a[normalize-space()='Employee List']")
    WebElement employeeListTab;

    @FindBy(xpath = "(//input[@placeholder='Type for hints...'])[1]")
    WebElement searchBox;

    @FindBy(xpath = "//button[@class='oxd-button oxd-button--medium oxd-button--secondary orangehrm-left-space']")
    WebElement searchBtn;

    public EmployeeListPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void searchAndEdit(String name) throws IOException{
        employeeListTab.click();
        searchBox.sendKeys(name);
        searchBtn.click();
        
        
        try {
            String searchValue = driver.findElement(By.xpath("//span[normalize-space()='(1) Record Found']")).getText();
            if ("(1) Record Found".equals(searchValue)) {
                String searchName = driver.findElement(By.xpath("(//div[contains(text(),'nakulya thurai')])[1]")).getText();
                if (searchName.equals("nakulya thurai")) {
                    driver.findElement(By.xpath("//div[@class='oxd-table-card-cell-checkbox']//i")).click();
                    driver.findElement(By.xpath("(//i[@class='oxd-icon bi-pencil-fill'])[1]")).click();
                }
            }

            

        } catch (NoSuchElementException e) {
            System.out.println("No Record Found");
        }
    }
}
