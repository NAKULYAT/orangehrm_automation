package com.selenium.orange_pages;


import java.io.IOException;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

import com.selenium.orange_utils.ScreenshotUtil;

public class PIMPage {
    WebDriver driver;

    @FindBy(xpath = "//a[normalize-space()='PIM']")
    WebElement pimTab;

    @FindBy(xpath = "//a[normalize-space()='Add Employee']")
    WebElement addEmployee;

    @FindBy(xpath = "//input[@placeholder='First Name']")
    WebElement firstName;

    @FindBy(xpath = "//input[@placeholder='Middle Name']")
    WebElement middleName;

    @FindBy(xpath = "//input[@placeholder='Last Name']")
    WebElement lastName;

    @FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[2]/div/label/span")
    WebElement toggleLoginDetails;

    @FindBy(xpath = "(//input[@class='oxd-input oxd-input--active'])[3]")
    WebElement username;

    @FindBy(xpath = "//div[@class='oxd-grid-item oxd-grid-item--gutters user-password-cell']//input[@type='password']")
    WebElement password;

    @FindBy(xpath = "//div[@class='oxd-grid-item oxd-grid-item--gutters']//input[@type='password']")
    WebElement confirmPassword;

    @FindBy(css = "button[type='submit']")
    WebElement saveBtn;

    public PIMPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void navigateToAddEmployee() {
        pimTab.click();
        addEmployee.click();
      
    }
    
    

    public void addEmployee(String fName, String mName, String lName, String user, String pass, String cpass) throws InterruptedException, IOException {
        firstName.sendKeys(fName);
        middleName.sendKeys(mName);
        lastName.sendKeys(lName);
        toggleLoginDetails.click();
        username.sendKeys(user);
        password.sendKeys(pass);
        confirmPassword.sendKeys(cpass);
        Thread.sleep(10000);
        ScreenshotUtil.captureScreenshot(driver, "src/test/resources/screenshot");
        saveBtn.click();
    }
}
